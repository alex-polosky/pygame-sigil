import pygame.rect as rect
Rect = rect.Rect
del rect

import parsing
import screen
import sprite
import tools
import version
import world
from locals import *

# I want to implement a simple HUD class
# Use the HUD class for displaying any
# scores or other important data

# also, perhaps a Particles Engine
